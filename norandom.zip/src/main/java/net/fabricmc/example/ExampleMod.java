package net.fabricmc.example;

import net.devtech.grossfabrichacks.instrumentation.InstrumentationApi;
import net.fabricmc.api.ModInitializer;
import net.minecraft.datafixer.fix.EntityUuidFix;
import net.minecraft.entity.Entity;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.MethodNode;

import java.util.Random;
import java.util.UUID;

public class ExampleMod implements ModInitializer {
	@Override
	public void onInitialize() {
		// This code runs as soon as Minecraft is in a mod-load-ready state.
		// However, some things (like resources) may still be uninitialized.
		// Proceed with mild caution.
		InstrumentationApi.retransform(Random.class, (s, b) -> {
			for (MethodNode node : b.methods) {
				if (node.name.equals("<init>") && node.desc.equals("()V")) {
					node.instructions.clear();
					node.visitVarInsn(Opcodes.ALOAD, 0);
					node.visitLdcInsn(0L);
					node.visitMethodInsn(Opcodes.INVOKESPECIAL, Type.getInternalName(Random.class), "<init>", "(J)V", false);
					node.visitInsn(Opcodes.RETURN);
				}
//				System.out.println(node.name);
//				System.out.println(node.desc);
			}
		});
		System.out.println("Hello Fabric world!");
	}
}
